/*
Integrante 1 - Nome: JOÃO PEDRO PORTA RA: 16039778
Integrante 2 - Nome: MARCELO DIB COUTINHO RA: 16023673
Integrante 3 - Nome: RAFAEL FIORAMONTE RA: 16032708
Resultados obtidos: Programa Funcionando Corretamente
Projeto básico: 100 % concluído - Obs: _____________________________________
(x) Opcional 1 - Obs: ______________________________________________________
(x) Opcional 2 - Obs: ______________________________________________________
(x) Opcional 3 - Obs: balanceamos a árvore após a recepção
(x) Opcional 4 - Obs: ______________________________________________________
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include "ST.h"
#include "STb.h"


int main(int argc, char *argv[]) {
  int numb, i, numero = 0, maxi;
  char palavra[100], num[10], l;
  char arquivoIn[20], arquivoOut[20], word[100], max[5];
  Tno *raiz = NULL;
  Ti *res;
  int n, w, r, s, b, p; //Argumentos ativados pelo usuário
  FILE *in, *out;

  n = w = r = s = b = p = 0;
  //---------------Pega argumentos----------------------
  /*
    todos os argumentos são recebidos, e então medidas iniciais
    são tomadas, tendo tambem a validação dos argumentos passados
  */
  if (argc > 1) {
    for (i = 1; i < argc; i++) {
      l = argv[i][1];
      switch (l) {
      case 'n': // Opcao para fazer contagem das palavras mais utilizadas (PROJETO BASICO)
        n = 1;
        numb = atoi(&argv[i][2]);
        numero = 0;
        break;
      case 'w': // Opcao para fazer escrita da arvore em arquivo (OPCIONAL 1)
        w = 1;
        strcpy(arquivoOut, &argv[i][2]);
        out = fopen(arquivoOut, "w");
        if(out == NULL) {
          puts("Erro ao abrir o arquivo");
          return 0;
        }
        break;
      case 'r': // Opcao para fazer leitura da arvore em arquivo (OPCIONAL 1)
        if (!w) {
          r = 1;
          strcpy(arquivoIn, &argv[i][2]);
          in = fopen(arquivoIn, "r");
          if(in == NULL) {
            puts("Erro ao abrir o arquivo");
            return 0;
          }
        }
        break;
      case 's': // Opcao para fazer busca de uma palavra na arvore (OPCIONAL 2)
        s = 1;
        strcpy(word, &argv[i][2]);
        break;
      case 'b': // Opcao para balancear a arvore (OPCIONAL 3)
        b = 1;
        break;
      case 'p': // Opcao para printar a arvore ate altura desejada (OPCIONAL 4)
        p = 1;
        maxi = atoi(&argv[i][2]);
        break;
      }
    }

  } else { // Se o usuario nao colocar argumentos suficientes
    printf("Argumentos insuficientes\n");
    exit(0);
  }
  // ===========================================================================
  // recepcao das palavras atravez de um arquivo
  if (r) { 
    i = 0;
    l = fgetc(in);                      
    while (!feof(in)) {                 // enquanto n for o final de arquivo continua o loop
      if ((l > 64 && l < 91) ||
          (l > 96 && l < 123)) {        // Se for letra maiúscula ou minúscula.
        palavra[i] = l;                 // coloca em um vetor.
        i++;
      } else {
        palavra[i] = '\0';              // caso n for letra finaliza a palavra com /0.

        if (strlen(palavra) >  0){       // se a palavra n for apenas o /0 coloca ela na árvore
          insere(&raiz, palavra, &numero, 0);
        }
        i = 0;
      }
      l = fgetc(in);                    // pega proximo caracter e continua loop.
    }
    fclose(in);
  // ===========================================================================
  // recepcao das palavras sem ser de arquivo
  } else {
    i = 0;
    l = fgetc(stdin);                 
    while (!feof(stdin)) {            
      if ((l > 64 && l < 91) ||
          (l > 96 && l < 123)) { 
        palavra[i] = l;         
        i++;
      } else {
        palavra[i] = '\0';

        if (strlen(palavra) > 0){ // se a palavra n for apenas o /0 coloca ela na árvore
          insere(&raiz, palavra, &numero, 0);
        }
        if (w)
          printaArq(palavra, out);
        i = 0;
      }
      l = fgetc(stdin); // pega proximo caracter e continua loop.
    }
  }
  // FIM RECEPCAO E INSERCAO
  // ===============================================================

  if(b) raiz  = balanceando(raiz); // Se b, balancea a arvore

  // printf("%li\n", altura(raiz));  Usado para debug

  // ===========================================================
  if (n) { // Se n, Printa os mais frequentes
    if (numero < numb)
      numb = numero;
    res = mais_frequente(numb, raiz);
    for (i = 0; i < numb; i++) {
      printaItem((res + i));
    }
    free(res);
  }
  // ===========================================================

  // ===========================================================
  // Se s, Procura a palavra word
  if (s) {
    long int alt;
    struct timeval t1, t2;
    gettimeofday(&t1, NULL); 
    alt = achaItem(raiz, word);
    gettimeofday(&t2, NULL);
    if (alt > 0) printf("%li %ld\n",alt, (1000000 * (t2.tv_sec - t1.tv_sec) + (t2.tv_usec - t1.tv_usec)));
  }
  // ===========================================================
  // Se p, printa arvore
  if (p) {
    printa_altura(raiz, maxi);
  }
  // ===========================================================
  // Se w, escreve arquivo
  if (w)
    fclose(out); // se w fecha o arquivo
  freeEveryOne(&raiz, 1);
  return 0;
}
