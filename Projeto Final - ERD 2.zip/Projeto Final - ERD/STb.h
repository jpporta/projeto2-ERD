long int altura(Tno *raiz);
int balancea( Tno *raiz );
Tno *rodaEsqEsq( Tno *raiz );
Tno *rodaEsqDir( Tno *raiz );
Tno *rodaDirEsq( Tno *raiz );
Tno *rodaDirDir( Tno *raiz );
Tno *balanceando( Tno *raiz );
